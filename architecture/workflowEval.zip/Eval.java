package main.java.workflowEval;

public class Eval {
    public Eval() {
        //TODO
    }

    public int evaluate(Mutation muation) {
        //TODO
        return 0;
    }
}