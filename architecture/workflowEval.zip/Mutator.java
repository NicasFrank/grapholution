package main.java.workflowEval;

import java.util.ArrayList;

public class Mutator {
    public Mutator() {
        //TODO
    }

    public ArrayList<Mutation> mutateGeneration(ArrayList<Mutation> mutations) {
        //TODO
        return null;
    }
}