package MineSweeper;

public class mineField {

public mineField() {
	for(int i = 0; i < 9; i++) {
			mineFieldShow[i] = "#";
			mineFieldStats[i] = 0;
	}
	mineFieldStats[1] = 10;
	mineFieldStats[6] = 10;
	for(int l = 0; l < 9; l++) {
				ifBombIncrement(l);
		}
};
private String[] mineFieldShow = new String[9];
private Integer[] mineFieldStats = new Integer[9];

public void statsIncrement(int l) {
	
		switch(l) {
		case 0:
			increase(l+1);
			increase(l+3);
			increase(l+4);
			break;
		case 3:
			increase(l-2);
			increase(l-3);
			increase(l+1);
			increase(l+3);
			increase(l+4);
			break;
		case 6:
			increase(l-2);
			increase(l-3);
			increase(l+1);
			break;
		case 2:
			increase(l-1);
			increase(l+2);
			increase(l+3);
			break;		
		case 5:
			increase(l+1);
			increase(l+3);
			increase(l-3);
			increase(l-4);
			increase(l+2);
			break;
		case 8:
			increase(l-1);
			increase(l-3);
			increase(l-4);
			break;
		case 1: 
			increase(l-1);
			increase(l+1);
			increase(l+3);
			increase(l+4);
			increase(l+2);
			break;
		case 7: 
			increase(l-1);
			increase(l+1);
			increase(l-3);
			increase(l-2);
			increase(l-4);
			break;
		default:
			increase(l-1);
			increase(l+1);
			increase(l+3);
			increase(l-3);
			increase(l+4);
			increase(l-2);
			increase(l-4);
			increase(l+2);
			break;
		}

};
public void increase(int l) {
	if(mineFieldStats[l]!=10) {
					mineFieldStats[l]++;
	}
};

public void printShow() {
	for(int p = 0; p < 9; p++) {
		printShowN(p);
	}
};
public void printShowN(int p) {
	System.out.print(mineFieldShow[p]);
	if(p==2||p==5||p==8) {
		System.out.print("\n");
	}
}
public void aufdecken(int x, int y) {
    switch(mineFieldStats[x+y*3]) {
    case 10:
    	mineFieldShow[x+y*3]="*";
    	break;
    case 0:
    	mineFieldShow[x+y*3]=".";
    	break;
    default:
    	mineFieldShow[x+y*3]= Integer.toString(mineFieldStats[x+y*3]);
    	break;
    }
}
public boolean mineGetroffen(int x, int y) {
    if(mineFieldStats[x+y*3]==10) {
    	System.out.println("game over!");
    	return true;
    }
    return false;
}

public void ifBombIncrement(int l) {
	if(mineFieldStats[l]==10) {
		statsIncrement(l);
	}
}

}
