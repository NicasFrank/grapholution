package MineSweeper;

import java.util.Scanner;

public class input {
	
	public input() {
		
	};
	private int inputX;
	private int inputY;
	public boolean richtigeEingabeX() {
		Scanner scan = new Scanner(System.in);
        try 
        { 
        	boolean testErfolgreich;
        	System.out.println("X: ");
            inputX = scan.nextInt();
            return testEingabe(inputX);
            
            
        }
        catch(Exception e)
        {
            System.out.println("Das ist keine ganze Dezimalzahl!");
            scan.reset();
            return false;

        }
	};
	public boolean richtigeEingabeY() {
		Scanner scan = new Scanner(System.in);
        try 
        { 
        	boolean testErfolgreich;
        	System.out.println("Y: ");
            inputY = scan.nextInt();
            return testEingabe(inputY);
            
            
        }
        catch(Exception e)
        {
            System.out.println("Das ist keine ganze Dezimalzahl!");
            scan.reset();
            return false;

        }
	};
	public boolean testEingabe(int eingabe) {
		if(eingabe >= 3)
        {
            System.out.println("Die Zahl ist zu gro�!");
            return false;
        }
        return true;
	};
	
	public void eingabeAbfrage() {
		while(!(richtigeEingabeX() && richtigeEingabeY())) {} //z�hlt das als 2 methoden aufrufe?
	};
	public boolean eingabeSchlecht(mineField feld) {
		eingabeAbfrage();
		System.out.println("Feld: " + inputX + ", " + inputY);
		feld.aufdecken(inputX, inputY);
	    feld.printShow();
	    return feld.mineGetroffen(inputX, inputY);
	    
	    
	};
}
