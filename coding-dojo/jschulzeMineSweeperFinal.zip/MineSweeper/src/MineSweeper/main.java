package MineSweeper;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		runGame();
	};
	static void runGame(){
		mineField minenFeld = new mineField();
		minenFeld.printShow();
		input in = new input(); 
		for(int i = 0; i < 6 && !in.eingabeSchlecht(minenFeld); i++) {   
		}
	};
	
};








